CREATE DATABASE cadastro_clientes;

USE cadastro_clientes;

CREATE TABLE clientes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    cidade VARCHAR(100) NOT NULL,
    estado VARCHAR(2) NOT NULL,
    cep VARCHAR(9) NOT NULL,
    email VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO clientes (nome, cidade, estado, cep, email) VALUES
('João Silva', 'São Paulo', 'SP', '01001-000', 'joao.silva@email.com'),
('Maria Oliveira', 'Rio de Janeiro', 'RJ', '20040-000', 'maria.oliveira@email.com'),
('Carlos Pereira', 'Belo Horizonte', 'MG', '30190-000', 'carlos.pereira@email.com'),
('Ana Souza', 'Porto Alegre', 'RS', '90010-000', 'ana.souza@email.com'),
('Pedro Costa', 'Salvador', 'BA', '40026-000', 'pedro.costa@email.com'),
('Juliana Santos', 'Brasília', 'DF', '70040-000', 'juliana.santos@email.com'),
('Fernando Almeida', 'Fortaleza', 'CE', '60010-000', 'fernando.almeida@email.com'),
('Patrícia Lima', 'Curitiba', 'PR', '80010-000', 'patricia.lima@email.com'),
('Ricardo Gomes', 'Recife', 'PE', '50010-000', 'ricardo.gomes@email.com'),
('Amanda Rocha', 'Manaus', 'AM', '69005-000', 'amanda.rocha@email.com'),
('Lucas Martins', 'Belém', 'PA', '66010-000', 'lucas.martins@email.com'),
('Isabela Ferreira', 'Goiânia', 'GO', '74010-000', 'isabela.ferreira@email.com'),
('Marcos Ribeiro', 'Vitória', 'ES', '29010-000', 'marcos.ribeiro@email.com'),
('Tatiane Nunes', 'Florianópolis', 'SC', '88010-000', 'tatiane.nunes@email.com'),
('Gustavo Henrique', 'Natal', 'RN', '59010-000', 'gustavo.henrique@email.com'),
('Camila Dias', 'Campo Grande', 'MS', '79002-000', 'camila.dias@email.com'),
('Roberto Andrade', 'Cuiabá', 'MT', '78005-000', 'roberto.andrade@email.com'),
('Larissa Castro', 'João Pessoa', 'PB', '58010-000', 'larissa.castro@email.com'),
('Eduardo Cardoso', 'Teresina', 'PI', '64000-000', 'eduardo.cardoso@email.com'),
('Vanessa Monteiro', 'Aracaju', 'SE', '49010-000', 'vanessa.monteiro@email.com');